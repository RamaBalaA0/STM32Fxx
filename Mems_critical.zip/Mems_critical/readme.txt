Three Threads 
1) Mems sensor LED blink.
2) All Led's switches on for 2 sec and then switches off.
3) Two led's switches on for 2 sec and then switches off.

Led's is shared resource here for threads.
So Led's are protected using mutex's.

Thread which grabs the mutex will be executed,other threads will wait till mutex is released.
Once,Mems sensor thread starts,it will keep on executing until user button is pressed.