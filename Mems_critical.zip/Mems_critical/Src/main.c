
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#ifdef _RTE_
#include "RTE_Components.h"             /* Component selection */
#endif
extern uint32_t os_time;
/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
//osThreadDef(Toggle_Leds, osPriorityNormal, 1, 0);
osThreadId tid_Toggle_Leds,tid_Toggle_Leds2;							 /* Thread id of threads     */
osThreadId tid_ACCELERO_MEMS_Test; 
osMutexDef(mutex);
osMutexId(MutexId);
	
uint32_t HAL_GetTick(void) { 
  return os_time; 
}

int16_t ThresholdHigh = 200;
int16_t ThresholdLow = -200;

/* Private function prototypes -----------------------------------------------*/
static void ACCELERO_ReadAcc(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Test ACCELERATOR MEMS Hardware.
  *         The main objective of this test is to check acceleration on 2 axes X and Y
  * @param  None
  * @retval None
  */
__IO uint8_t UserPressButton = 0;
#define ABS(x)         (x < 0) ? (-x) : x
void Toggle_Leds(void const *argument) //Switches on all led's
{
	osMutexWait (MutexId,osWaitForever); // Grab Mutex
	osSignalWait(2U, osWaitForever);    /* wait for an event flag 0x0001 */
  BSP_LED_On(LED3);
  HAL_Delay(100);
  BSP_LED_On(LED4);
  HAL_Delay(100);
  BSP_LED_On(LED5);
  HAL_Delay(100);
  BSP_LED_On(LED6);
  HAL_Delay(2000); 										// Led's will be on for 2 secs
		BSP_LED_Off(LED3);
    BSP_LED_Off(LED4);
    BSP_LED_Off(LED5);
    BSP_LED_Off(LED6);
		HAL_Delay(500);
	  osMutexRelease (MutexId);
	//osSignalSet(tid_ACCELERO_MEMS_Test, 0x0001);          
}

void Toggle_Leds2(void const *argument)
{
	osMutexWait (MutexId,osWaitForever);
	osSignalWait(3U, osWaitForever);    /* wait for an event flag 0x0001 */
  BSP_LED_On(LED3);
  HAL_Delay(100);
  BSP_LED_On(LED6);
  HAL_Delay(2000);									// 2 Led's will be on for 2 secs
		//osMutexRelease (MutexId);
		BSP_LED_Off(LED3);
    BSP_LED_Off(LED4);
    BSP_LED_Off(LED5);
    BSP_LED_Off(LED6);
		HAL_Delay(500);
	  osMutexRelease (MutexId);
	//osSignalSet(tid_ACCELERO_MEMS_Test, 0x0001);          


}
void ACCELERO_MEMS_Test(void const *argument)
{
	  osMutexWait (MutexId,osWaitForever);
		osSignalWait(1U, osWaitForever); 
//osSignalSet(tid_Toggle_Leds, 0x0001);      	
  /* Init Accelerometer MEMS */
  if(BSP_ACCELERO_Init() != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler(); 
  }
  //int i;
  UserPressButton = 0;
  while (!(Buttons_GetState() & 1U))   //When button is pressed,thread will be terminated
  {
    ACCELERO_ReadAcc();
		//osDelay(500);
		//osSignalSet(tid_Toggle_Leds, 0x0001);       
  }
	BSP_LED_Off(LED3);
  BSP_LED_Off(LED4);
  BSP_LED_Off(LED5);
  BSP_LED_Off(LED6);
	osMutexRelease (MutexId);
	osThreadTerminate(tid_ACCELERO_MEMS_Test);
	//osSignalSet(tid_Toggle_Leds,2U);
  //BSP_LED_On(LED3);  
	
}

/**
  * @brief  Read Acceleration data.
  * @param  None
  * @retval None
  */
static void ACCELERO_ReadAcc(void)
{
  /* Accelerometer variables */
  int16_t buffer[3] = {0};
  int16_t xval, yval = 0x00;
  
  /* Read Acceleration */
  BSP_ACCELERO_GetXYZ(buffer);
  
  xval = buffer[0];
  yval = buffer[1];
  
  if((ABS(xval))>(ABS(yval)))
  {
    if(xval > ThresholdHigh)
    { 
      /* LED5 On */
      BSP_LED_On(LED5);
      HAL_Delay(10);
			//osDelay(10);
    }
    else if(xval < ThresholdLow)
    { 
      /* LED4 On */
      BSP_LED_On(LED4);      
      HAL_Delay(10);
			//osDelay(10);
    }
    else
    { 
      HAL_Delay(10);
			//osDelay(10);
    }
  }
  else
  {
    if(yval < ThresholdLow)
    {
      /* LED6 On */
      BSP_LED_On(LED6);
      HAL_Delay(10);
			//osDelay(10);
    }
    else if(yval > ThresholdHigh)
    {
      /* LED3 On */
      BSP_LED_On(LED3);
      HAL_Delay(10);
			//osDelay(10);
    } 
    else
    { 
      HAL_Delay(10);
			//osDelay(10);
    }
  } 
  
  BSP_LED_Off(LED3);
  BSP_LED_Off(LED4);
  BSP_LED_Off(LED5);
  BSP_LED_Off(LED6);
	//osSignalSet(tid_Toggle_Leds, 0x0001);
}

osThreadDef(Toggle_Leds, osPriorityNormal, 1, 0);
osThreadDef(Toggle_Leds2, osPriorityNormal, 1, 0);
osThreadDef(ACCELERO_MEMS_Test, osPriorityNormal, 1, 0);


int main(void)
{ 
                                        // when using CMSIS RTOS
  osKernelInitialize();                 // initialize CMSIS-RTOS

 /* STM32F4xx HAL library initialization:
       - Configure the Flash prefetch, instruction and Data caches
       - Configure the Systick to generate an interrupt each 1 msec
       - Set NVIC Group Priority to 4
       - Global MSP (MCU Support Package) initialization
     */
  HAL_Init();
  
  /* Configure LED3, LED4, LED5 and LED6 */
  BSP_LED_Init(LED3);
  BSP_LED_Init(LED4); 
  BSP_LED_Init(LED5);
  BSP_LED_Init(LED6);
  
  /* Configure the system clock to 168 MHz */
  SystemClock_Config();
  
  /* Configure USER Button */
  BSP_PB_Init(BUTTON_KEY, BUTTON_MODE_EXTI);
  
	/* Threads & Mutexs creation */
  tid_Toggle_Leds = osThreadCreate(osThread(Toggle_Leds), NULL);
  tid_Toggle_Leds2 = osThreadCreate(osThread(Toggle_Leds2), NULL);
  tid_ACCELERO_MEMS_Test = osThreadCreate(osThread(ACCELERO_MEMS_Test), NULL);
  MutexId=osMutexCreate(osMutex(mutex));


    osKernelStart();                      // start thread execution 

		while(1)
		{
				osSignalSet(tid_Toggle_Leds, 2U);
			  osSignalSet(tid_Toggle_Leds2, 3U);
			  osSignalSet(tid_ACCELERO_MEMS_Test, 1U);
			  osDelay(7000);
			  //osThreadTerminate(tid_ACCELERO_MEMS_Test);
		}
			  
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 168000000
  *            HCLK(Hz)                       = 168000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 4
  *            APB2 Prescaler                 = 2
  *            HSE Frequency(Hz)              = 8000000
  *            PLL_M                          = 8
  *            PLL_N                          = 336
  *            PLL_P                          = 2
  *            PLL_Q                          = 7
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale1 mode
  *            Flash Latency(WS)              = 5
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();
  
  /* The voltage scaling allows optimizing the power consumption when the device is 
     clocked below the maximum system frequency, to update the voltage scaling value 
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  
  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);

  /* STM32F405x/407x/415x/417x Revision Z devices: prefetch is supported  */
  if (HAL_GetREVID() == 0x1001)
  {
    /* Enable the Flash prefetch */
    __HAL_FLASH_PREFETCH_BUFFER_ENABLE();
  }
}
/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
  /* Turn LED5 on */
  BSP_LED_On(LED5);
  while(1)
  {
  }
}

#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
